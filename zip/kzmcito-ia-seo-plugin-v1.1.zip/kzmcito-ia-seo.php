<?php
/**
 * Plugin Name: KzmCITO IA SEO Multilenguaje
 * Description: IA SEO multilenguaje con caché y RankMath.
 * Version: 1.1.0
 */

defined('ABSPATH') || exit;

define('KZMCITO_IA_VERSION', '1.1.0');
define('KZMCITO_IA_PATH', plugin_dir_path(__FILE__));

require_once KZMCITO_IA_PATH . 'includes/class-cache.php';
require_once KZMCITO_IA_PATH . 'includes/class-generator.php';
require_once KZMCITO_IA_PATH . 'includes/class-frontend.php';
require_once KZMCITO_IA_PATH . 'includes/class-admin.php';

add_action('plugins_loaded', function () {
    new Kzmcito_IA_Frontend();
    if (is_admin()) new Kzmcito_IA_Admin();
});
