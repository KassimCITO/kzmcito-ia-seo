<?php
function kzmcito_generate_with_openai($post_id,$language){ return true; }
