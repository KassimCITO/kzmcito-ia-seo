<?php
add_filter('the_content', function($c){ return $c; }, 20);
