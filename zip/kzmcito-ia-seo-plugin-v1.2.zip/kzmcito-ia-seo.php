<?php
/**
 * Plugin Name: KzmCITO IA SEO Multilenguaje
 * Description: Sistema editorial con IA para SEO y caché multilenguaje integrado con RankMath.
 * Version: 1.2
 * Author: KassimCITO
 */
if (!defined('ABSPATH')) exit;
define('KZMCITO_IA_SEO_VERSION', '1.2');
require_once plugin_dir_path(__FILE__) . 'includes/admin-settings.php';
require_once plugin_dir_path(__FILE__) . 'includes/meta-box.php';
require_once plugin_dir_path(__FILE__) . 'includes/openai-generator.php';
require_once plugin_dir_path(__FILE__) . 'includes/frontend-content.php';
