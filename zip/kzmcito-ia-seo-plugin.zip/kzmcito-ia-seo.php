<?php
/**
 * Plugin Name: KzmCITO IA SEO Multilenguaje
 * Description: Generador y cacheador de contenido multilenguaje con IA, optimizado para RankMath y medios digitales.
 * Version: 1.0.0
 */

defined('ABSPATH') || exit;

define('KZMCITO_IA_VERSION', '1.0.0');
define('KZMCITO_IA_PATH', plugin_dir_path(__FILE__));

require_once KZMCITO_IA_PATH . 'includes/class-cache.php';
require_once KZMCITO_IA_PATH . 'includes/class-frontend.php';
require_once KZMCITO_IA_PATH . 'includes/class-admin.php';

add_action('plugins_loaded', function () {
    new Kzmcito_IA_Frontend();
    if (is_admin()) {
        new Kzmcito_IA_Admin();
    }
});
