<?php
class Kzmcito_IA_Admin {

    public function __construct() {
        add_action('add_meta_boxes', [$this, 'metabox']);
        add_action('save_post', [$this, 'save'], 10, 2);
    }

    public function metabox() {
        add_meta_box(
            'kzmcito_ia_box',
            'IA Multilenguaje',
            [$this, 'render'],
            'post',
            'side',
            'default'
        );
    }

    public function render($post) {
        ?>
        <p><strong>Idioma:</strong></p>
        <select name="kzmcito_lang">
            <option value="en">Inglés</option>
            <option value="fr">Francés</option>
            <option value="pt">Portugués</option>
        </select>
        <p>
            <button class="button button-primary" name="kzmcito_generate" value="1">
                Generar versión IA
            </button>
        </p>
        <?php
    }

    public function save($post_id, $post) {
        if (!isset($_POST['kzmcito_generate'])) return;
        if ($post->post_status !== 'publish') return;

        $lang = sanitize_text_field($_POST['kzmcito_lang'] ?? '');
        if (!$lang) return;

        // Placeholder IA output (mock)
        Kzmcito_IA_Cache::set($post_id, $lang, 'GLOBAL', [
            'content_html' => '<p>[Contenido generado por IA en ' . esc_html($lang) . ']</p>'
        ]);
    }
}
