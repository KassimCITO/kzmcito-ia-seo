<?php
class Kzmcito_IA_Frontend {

    public function __construct() {
        add_filter('the_content', [$this, 'inject_content'], 20);
        add_action('wp_enqueue_scripts', [$this, 'assets']);
    }

    public function assets() {
        wp_enqueue_script(
            'kzmcito-lang-switcher',
            plugins_url('../assets/js/lang-switcher.js', __FILE__),
            [],
            KZMCITO_IA_VERSION,
            true
        );
    }

    public function inject_content($content) {
        if (!is_singular() || is_admin()) return $content;

        $lang = $this->detect_lang();
        if ($lang === 'es') return $content;

        $cache = Kzmcito_IA_Cache::get(get_the_ID(), $lang);
        if (!empty($cache['content_html'])) {
            return $cache['content_html'];
        }
        return $content;
    }

    private function detect_lang() {
        if (!empty($_GET['lang'])) {
            return sanitize_text_field($_GET['lang']);
        }
        if (!empty($_COOKIE['kzmcito_lang'])) {
            return sanitize_text_field($_COOKIE['kzmcito_lang']);
        }
        return 'es';
    }
}
