<?php
class Kzmcito_IA_Cache {

    public static function key($lang, $variant = 'GLOBAL') {
        return '_kzmcito_ia_content_' . $lang . '_' . $variant;
    }

    public static function get($post_id, $lang, $variant = 'GLOBAL') {
        return get_post_meta($post_id, self::key($lang, $variant), true);
    }

    public static function set($post_id, $lang, $variant, $data) {
        $data['generated_at'] = time();
        $data['prompt_version'] = '1.1';
        update_post_meta($post_id, self::key($lang, $variant), $data);
    }

    public static function delete_all($post_id) {
        global $wpdb;
        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $wpdb->postmeta WHERE post_id = %d AND meta_key LIKE %s",
                $post_id,
                '_kzmcito_ia_content_%'
            )
        );
    }
}
